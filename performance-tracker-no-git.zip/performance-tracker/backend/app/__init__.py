"""Initialize the FastAPI application.

This package contains the top‑level FastAPI application and supporting modules for
authentication, data access and API routing.
"""
